package crud.oht;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OhtApplication {

	public static void main(String[] args) {
		SpringApplication.run(OhtApplication.class, args);
	}

}
