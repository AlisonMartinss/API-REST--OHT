package crud.oht;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OhtApplicationTests {

	@Test
	void contextLoads() {
	}

}
